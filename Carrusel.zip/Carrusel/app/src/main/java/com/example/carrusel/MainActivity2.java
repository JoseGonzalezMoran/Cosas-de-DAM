package com.example.carrusel;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

public class MainActivity2 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        ImageView carrusel=(ImageView) findViewById(R.id.carrusel);
        carrusel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Drawable foto1 = getResources().getDrawable(R.drawable.maggie);
                carrusel.setImageDrawable(foto1);
                Drawable foto2 = getResources().getDrawable(R.drawable.cain);
                carrusel.setImageDrawable(foto2);
                Drawable foto3 = getResources().getDrawable(R.drawable.eve);
                carrusel.setImageDrawable(foto3);
                Drawable foto4 = getResources().getDrawable(R.drawable.samson);
                carrusel.setImageDrawable(foto4);
                Drawable foto5 = getResources().getDrawable(R.drawable.azazel);
                carrusel.setImageDrawable(foto5);
            }
        });
    }
}
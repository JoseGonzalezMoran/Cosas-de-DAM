package com.example.preferencias;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.DialogInterface;
import android.os.Bundle;
import android.os.Environment;
import android.text.InputType;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;

public class MainActivity extends AppCompatActivity {
    private String m_Text = "";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        Button crear=findViewById(R.id.crear);
        Button leer=findViewById(R.id.leer);
        Button path=findViewById(R.id.path);
        Button modificar=findViewById(R.id.modificar);
        crear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                crearArchivo();
            }
        });
        leer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                leerArchivo();
            }
        });
        path.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

            }
        });
        modificar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                crearArchivo();
            }
        });
    }
    private void crearArchivo(){
            AlertDialog.Builder builder = new AlertDialog.Builder(this);
            builder.setTitle("Escribe la ruta del fichero");
            final EditText input = new EditText(this);
            input.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);
            builder.setView(input);
            builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    m_Text = input.getText().toString();
                }
            });
            builder.setNegativeButton("Cancelar", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    dialog.cancel();
                }
            });
            builder.show();
        try {
            File nuevaCarpeta = new File(Environment.getExternalStorageDirectory(), "Carpeta");
            if (!nuevaCarpeta.exists()) {
                nuevaCarpeta.mkdir();
            }
            try {
                File file = new File(nuevaCarpeta, String.valueOf(input));
                file.createNewFile();
            } catch (Exception ex) {
                Log.e("Error", "ex: " + ex);
            }
        } catch (Exception e) {
            Log.e("Error", "e: "+e);
        }
        try{
            OutputStreamWriter output=new OutputStreamWriter(openFileOutput(input+".txt", Context.MODE_PRIVATE));
            output.write("Mensaje de prueba");
            output.close();
        }catch (Exception e){
            Log.e("Error","e: "+e);
        }
    }
    public void leerArchivo(){
            AlertDialog.Builder builder = new AlertDialog.Builder(this);
            builder.setTitle("Escribe la ruta del archivo para leer");
            final EditText input = new EditText(this);
            input.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);
            builder.setView(input);
            builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    m_Text = input.getText().toString();
                }
            });
            builder.setNegativeButton("Cancelar", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    dialog.cancel();
                }
            });
            builder.show();
            try{
        File nuevaCarpeta =new File(Environment.getExternalStorageDirectory(),"Carpeta");
        if (!nuevaCarpeta.exists()) {
            String text = "El archivo no existe";
            Toast toast = Toast.makeText(this, text, Toast.LENGTH_LONG);
            toast.show();
        }
            try {
                BufferedReader br=new BufferedReader(new InputStreamReader(openFileInput(input+".txt")));
                String linea= br.readLine();
                while(linea !=null){
                    Log.i("ddd","");
                }
                br.close();
            } catch (Exception ex) {
                Log.e("Error", "e: " + ex);
            }
        } catch(Exception e){
            Log.e("Error","e: "+e);
            }
        }
}
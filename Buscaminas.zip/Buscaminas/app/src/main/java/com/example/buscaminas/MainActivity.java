package com.example.buscaminas;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;

public class MainActivity extends AppCompatActivity {
    ArrayList<Integer> campo=new ArrayList<Integer>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        TextView cabecera=(TextView) findViewById(R.id.textView);
        TextView Posicion1=(TextView) findViewById(R.id.textView2);
        TextView Posicion2=(TextView) findViewById(R.id.textView3);
        TextView Posicion3=(TextView) findViewById(R.id.textView4);
        TextView Posicion4=(TextView) findViewById(R.id.textView5);
        TextView Posicion5=(TextView) findViewById(R.id.textView6);
        TextView Posicion6=(TextView) findViewById(R.id.textView7);
        TextView Posicion7=(TextView) findViewById(R.id.textView8);
        TextView Posicion8=(TextView) findViewById(R.id.textView9);
        TextView Posicion9=(TextView) findViewById(R.id.textView10);
        TextView Posicion10=(TextView) findViewById(R.id.textView11);
        TextView Posicion11=(TextView) findViewById(R.id.textView12);
        TextView Posicion12=(TextView) findViewById(R.id.textView13);
        TextView Posicion13=(TextView) findViewById(R.id.textView14);
        TextView Posicion14=(TextView) findViewById(R.id.textView15);
        TextView Posicion15=(TextView) findViewById(R.id.textView16);
        TextView Posicion16=(TextView) findViewById(R.id.textView17);
        TextView Posicion17=(TextView) findViewById(R.id.textView18);
        TextView Posicion18=(TextView) findViewById(R.id.textView19);
        TextView Posicion19=(TextView) findViewById(R.id.textView20);
        TextView Posicion20=(TextView) findViewById(R.id.textView21);
        TextView Posicion21=(TextView) findViewById(R.id.textView22);
        TextView Posicion22=(TextView) findViewById(R.id.textView23);
        TextView Posicion23=(TextView) findViewById(R.id.textView24);
        TextView Posicion24=(TextView) findViewById(R.id.textView25);
        TextView Posicion25=(TextView) findViewById(R.id.textView26);
        Button menu=(Button) findViewById(R.id.button);
        TextView Puntuacion=(TextView) findViewById(R.id.textView27);
        TextView Fallos=(TextView) findViewById(R.id.textView28);
        campo.add(1);
        campo.add(0);
        campo.add(1);
        campo.add(0);
        campo.add(1);
        campo.add(0);
        campo.add(1);
        campo.add(0);
        campo.add(1);
        campo.add(0);
        campo.add(1);
        campo.add(0);
        campo.add(1);
        campo.add(0);
        campo.add(1);
        campo.add(0);
        campo.add(1);
        campo.add(0);
        campo.add(1);
        campo.add(0);
        campo.add(1);
        campo.add(0);
        campo.add(1);
        campo.add(0);
        campo.add(0);
        //Collections.shuffle(campo);
        Posicion1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(campo.get(0)==0){
                    Posicion1.setVisibility(view.INVISIBLE);
                }else{
                    Posicion1.setBackgroundColor(Color.blue(R.color.black));
                }
            }
        });
        Posicion2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(campo.get(1)==1){
                    Posicion2.setVisibility(view.INVISIBLE);
                }else{
                    Posicion2.setBackgroundColor(Color.blue(R.color.black));
                }
            }
        });
        Posicion3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(campo.get(2)==1){
                    Posicion3.setVisibility(view.INVISIBLE);
                }else{
                    Posicion3.setBackgroundColor(Color.blue(R.color.black));
                }
            }
        });
        Posicion4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(campo.get(3)==1){
                    Posicion4.setVisibility(view.INVISIBLE);
                }else{
                    Posicion4.setBackgroundColor(Color.blue(R.color.black));
                }
            }
        });
        Posicion5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(campo.get(4)==1){
                    Posicion5.setVisibility(view.INVISIBLE);
                }else{
                    Posicion5.setBackgroundColor(Color.blue(R.color.black));
                }
            }
        });
        Posicion6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(campo.get(5)==1){
                    Posicion6.setVisibility(view.INVISIBLE);
                }else{
                    Posicion6.setBackgroundColor(Color.blue(R.color.black));
                }
            }
        });
        Posicion7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(campo.get(6)==1){
                    Posicion7.setVisibility(view.INVISIBLE);
                }else{
                    Posicion7.setBackgroundColor(Color.blue(R.color.black));
                }
            }
        });
        Posicion8.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(campo.get(7)==1){
                    Posicion8.setVisibility(view.INVISIBLE);
                }else{
                    Posicion8.setBackgroundColor(Color.blue(R.color.black));
                }
            }
        });
        Posicion9.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(campo.get(8)==1){
                    Posicion9.setVisibility(view.INVISIBLE);
                }else{
                    Posicion9.setBackgroundColor(Color.blue(R.color.black));
                }
            }
        });
        Posicion10.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(campo.get(9)==1){
                    Posicion10.setVisibility(view.INVISIBLE);
                }else{
                    Posicion10.setBackgroundColor(Color.blue(R.color.black));
                }
            }
        });
        Posicion11.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(campo.get(10)==1){
                    Posicion11.setVisibility(view.INVISIBLE);
                }else{
                    Posicion11.setBackgroundColor(Color.blue(R.color.black));
                }
            }
        });
        Posicion12.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(campo.get(11)==1){
                    Posicion12.setVisibility(view.INVISIBLE);
                }else{
                    Posicion12.setBackgroundColor(Color.blue(R.color.black));
                }
            }
        });
        Posicion13.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(campo.get(12)==1){
                    Posicion13.setVisibility(view.INVISIBLE);
                }else{
                    Posicion13.setBackgroundColor(Color.blue(R.color.black));
                }
            }
        });
        Posicion14.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(campo.get(13)==1){
                    Posicion14.setVisibility(view.INVISIBLE);
                }else{
                    Posicion14.setBackgroundColor(Color.blue(R.color.black));
                }
            }
        });
        Posicion15.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(campo.get(14)==1){
                    Posicion15.setVisibility(view.INVISIBLE);
                }else{
                    Posicion15.setBackgroundColor(Color.blue(R.color.black));
                }
            }
        });
        Posicion16.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(campo.get(15)==1){
                    Posicion16.setVisibility(view.INVISIBLE);
                }else{
                    Posicion16.setBackgroundColor(Color.blue(R.color.black));
                }
            }
        });
        Posicion17.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(campo.get(16)==1){
                    Posicion17.setVisibility(view.INVISIBLE);
                }else{
                    Posicion17.setBackgroundColor(Color.blue(R.color.black));
                }
            }
        });
        Posicion18.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(campo.get(17)==1){
                    Posicion18.setVisibility(view.INVISIBLE);
                }else{
                    Posicion18.setBackgroundColor(Color.blue(R.color.black));
                }
            }
        });
        Posicion19.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(campo.get(18)==1){
                    Posicion19.setVisibility(view.INVISIBLE);
                }else{
                    Posicion19.setBackgroundColor(Color.blue(R.color.black));
                }
            }
        });
        Posicion20.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(campo.get(19)==1){
                    Posicion20.setVisibility(view.INVISIBLE);
                }else{
                    Posicion20.setBackgroundColor(Color.blue(R.color.black));
                }
            }
        });
        Posicion21.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(campo.get(20)==1){
                    Posicion21.setVisibility(view.INVISIBLE);
                }else{
                    Posicion21.setBackgroundColor(Color.blue(R.color.black));
                }
            }
        });
        Posicion22.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(campo.get(21)==1){
                    Posicion22.setVisibility(view.INVISIBLE);
                }else{
                    Posicion22.setBackgroundColor(Color.blue(R.color.black));
                }
            }
        });
        Posicion23.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(campo.get(22)==1){
                    Posicion23.setVisibility(view.INVISIBLE);
                }else{
                    Posicion23.setBackgroundColor(Color.blue(R.color.black));
                }
            }
        });
        Posicion24.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(campo.get(23)==1){
                    Posicion24.setVisibility(view.INVISIBLE);
                }else{
                    Posicion24.setBackgroundColor(Color.blue(R.color.black));
                }
            }
        });
        Posicion25.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(campo.get(24)==1){
                    Posicion25.setVisibility(view.INVISIBLE);
                }else{
                    Posicion25.setBackgroundColor(Color.blue(R.color.black));
                }
            }
        });
    }
}
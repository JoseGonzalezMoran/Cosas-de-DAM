package com.example.parking;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class Menu extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu);
        Button levantar=(Button) findViewById(R.id.open);
        Button bloquear=(Button) findViewById(R.id.block);
        Button in=(Button) findViewById(R.id.in);
        Button out=(Button)findViewById(R.id.out);
        EditText matricula=(EditText) findViewById(R.id.matricula);
        TextView info=(TextView) findViewById(R.id.infoabonados);
        levantar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

            }
        });
        bloquear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

            }
        });
        in.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view){

            }
        });
        out.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

            }
        });
    }
}
package com.example.parking;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.DialogInterface;
import android.os.Bundle;
import android.os.Environment;
import android.text.InputType;
import android.util.Log;
import android.widget.EditText;

import java.io.File;
import java.io.OutputStreamWriter;

public class Configuracion extends AppCompatActivity {
    private String ruta="";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_configuracion);

    }
    public void crearFichero(){
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Escribe la ruta del fichero");
        final EditText input = new EditText(this);
        input.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);
        builder.setView(input);
        builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                ruta = input.getText().toString();
            }
        });
        builder.setNegativeButton("Cancelar", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.cancel();
            }
        });
        builder.show();
        try {
            File nuevaCarpeta = new File(Environment.getExternalStorageDirectory(), "Carpeta");
            if (!nuevaCarpeta.exists()) {
                nuevaCarpeta.mkdir();
            }
            try {
                File file = new File(nuevaCarpeta, String.valueOf(input));
                file.createNewFile();
            } catch (Exception ex) {
                Log.e("Error", "ex: " + ex);
            }
        } catch (Exception e) {
            Log.e("Error", "e: "+e);
        }
        try{
            OutputStreamWriter output=new OutputStreamWriter(openFileOutput(input+".txt", Context.MODE_PRIVATE));
            output.write("Mensaje de prueba");
            output.close();
        }catch (Exception e){
            Log.e("Error","e: "+e);
        }
    }
}
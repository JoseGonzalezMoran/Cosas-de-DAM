
public class Class {

}

package com.example.ruletarusa;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

import java.util.ArrayList;
import java.util.Collections;

public class Menu extends AppCompatActivity {
    int clicks =0;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu);
        final Button cargar = (Button) findViewById(R.id.Dificultad);
        final Button empezar = (Button) findViewById(R.id.Empezar);
        final ImageView bala1 = (ImageView) findViewById(R.id.bala1);
        final ImageView bala2 = (ImageView) findViewById(R.id.bala2);
        final ImageView bala3 = (ImageView) findViewById(R.id.bala3);
        cargar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                clicks++;
                switch (clicks) {
                    case 0:
                        bala1.setVisibility(View.VISIBLE);
                        break;
                    case 1:
                        bala2.setVisibility(View.VISIBLE);
                        break;
                    case 2:
                        bala3.setVisibility(View.VISIBLE);
                        break;
                }
            }
        });
        empezar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(clicks==0) {
                    Intent intent = new Intent(Menu.this, Juego.class);
                    Bundle bundle = new Bundle();
                    intent.putExtras(bundle);
                    startActivity(intent);
                }else if(clicks==1){
                    Intent intent = new Intent(Menu.this, Juego2.class);
                    Bundle bundle = new Bundle();
                    intent.putExtras(bundle);
                    startActivity(intent);
                }else{
                    Intent intent = new Intent(Menu.this, Juego3.class);
                    Bundle bundle = new Bundle();
                    intent.putExtras(bundle);
                    startActivity(intent);
                }
            }
        });
    }
}
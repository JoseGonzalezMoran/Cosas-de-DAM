package com.example.ruletarusa;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;

import java.util.ArrayList;
import java.util.Collections;

public class Juego2 extends AppCompatActivity {
    private ArrayList<Integer> tambor=new ArrayList<Integer>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_juego2);
        final ImageButton bala1=(ImageButton)findViewById(R.id.boton1);
        final ImageButton bala2=(ImageButton)findViewById(R.id.boton2);
        final ImageButton bala3=(ImageButton)findViewById(R.id.boton3);
        final ImageButton bala4=(ImageButton)findViewById(R.id.boton4);
        final ImageButton bala5=(ImageButton)findViewById(R.id.boton5);
        final ImageButton bala6=(ImageButton)findViewById(R.id.boton6);
        final ImageButton continuar =(ImageButton)findViewById(R.id.boton);
        final ImageButton reiniciar=(ImageButton) findViewById(R.id.reiniciar);
        final Button menuprincipal=(Button)findViewById(R.id.menuprincipal);
        final ImageView finperder=(ImageView)findViewById(R.id.imageView1);
        final ImageView finganar=(ImageView)findViewById(R.id.imageView2);
        final ImageView finganar2=(ImageView)findViewById(R.id.imageView3);
        final ImageView finganar3=(ImageView)findViewById(R.id.imageView4);
        final ImageView finganar4=(ImageView)findViewById(R.id.imageView5);
        final ImageView finganar5=(ImageView)findViewById(R.id.imageView6);
        final ImageView finganar6=(ImageView)findViewById(R.id.imageView7);
        tambor.add(1);
        tambor.add(1);
        tambor.add(0);
        tambor.add(0);
        tambor.add(0);
        tambor.add(0);
        Collections.shuffle(tambor);
        continuar.setVisibility(View.INVISIBLE);
        bala1.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                bala1.setVisibility(View.INVISIBLE);
                finganar.setVisibility(View.INVISIBLE);
                finganar2.setVisibility(View.INVISIBLE);
                finganar3.setVisibility(View.INVISIBLE);
                finganar4.setVisibility(View.INVISIBLE);
                finganar5.setVisibility(View.INVISIBLE);
                finganar6.setVisibility(View.INVISIBLE);
                if(tambor.get(0)==1){
                    finperder.setVisibility( View.VISIBLE);
                    continuar.setVisibility(View.VISIBLE);
                }else{
                    finganar.setVisibility(View.VISIBLE);
                }
            }
        });

        bala2.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                bala2.setVisibility(View.INVISIBLE);
                finganar.setVisibility(View.INVISIBLE);
                finganar2.setVisibility(View.INVISIBLE);
                finganar3.setVisibility(View.INVISIBLE);
                finganar4.setVisibility(View.INVISIBLE);
                finganar5.setVisibility(View.INVISIBLE);
                finganar6.setVisibility(View.INVISIBLE);
                if(tambor.get(1)==1){
                    finperder.setVisibility( View.VISIBLE);
                    continuar.setVisibility(View.VISIBLE);
                }else{
                    finganar2.setVisibility(View.VISIBLE);
                }
            }
        });

        bala3.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                bala3.setVisibility(View.INVISIBLE);
                finganar.setVisibility(View.INVISIBLE);
                finganar2.setVisibility(View.INVISIBLE);
                finganar3.setVisibility(View.INVISIBLE);
                finganar4.setVisibility(View.INVISIBLE);
                finganar5.setVisibility(View.INVISIBLE);
                finganar6.setVisibility(View.INVISIBLE);
                if(tambor.get(2)==1){
                    finperder.setVisibility( View.VISIBLE);
                    continuar.setVisibility(View.VISIBLE);
                }else{
                    finganar3.setVisibility(View.VISIBLE);
                }
            }
        });

        bala4.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                bala4.setVisibility(View.INVISIBLE);
                finganar.setVisibility(View.INVISIBLE);
                finganar2.setVisibility(View.INVISIBLE);
                finganar3.setVisibility(View.INVISIBLE);
                finganar4.setVisibility(View.INVISIBLE);
                finganar5.setVisibility(View.INVISIBLE);
                finganar6.setVisibility(View.INVISIBLE);
                if(tambor.get(3)==1){
                    finperder.setVisibility( View.VISIBLE);
                    continuar.setVisibility(View.VISIBLE);
                }else{
                    finganar4.setVisibility(View.VISIBLE);
                }
            }
        });

        bala5.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                bala5.setVisibility(View.INVISIBLE);
                finganar.setVisibility(View.INVISIBLE);
                finganar2.setVisibility(View.INVISIBLE);
                finganar3.setVisibility(View.INVISIBLE);
                finganar4.setVisibility(View.INVISIBLE);
                finganar5.setVisibility(View.INVISIBLE);
                finganar6.setVisibility(View.INVISIBLE);
                if(tambor.get(4)==1){
                    finperder.setVisibility( View.VISIBLE);
                    continuar.setVisibility(View.VISIBLE);
                }else{
                    finganar5.setVisibility(View.VISIBLE);
                }
            }
        });

        bala6.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                bala6.setVisibility(View.INVISIBLE);
                finganar.setVisibility(View.INVISIBLE);
                finganar2.setVisibility(View.INVISIBLE);
                finganar3.setVisibility(View.INVISIBLE);
                finganar4.setVisibility(View.INVISIBLE);
                finganar5.setVisibility(View.INVISIBLE);
                finganar6.setVisibility(View.INVISIBLE);
                if(tambor.get(5)==1){
                    finperder.setVisibility( View.VISIBLE);
                    continuar.setVisibility(View.VISIBLE);
                }else{
                    finganar6.setVisibility(View.VISIBLE);
                }
            }
        });
        continuar.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                Collections.shuffle(tambor);
                bala1.setVisibility(View.VISIBLE);
                bala2.setVisibility(View.VISIBLE);
                bala3.setVisibility(View.VISIBLE);
                bala4.setVisibility(View.VISIBLE);
                bala5.setVisibility(View.VISIBLE);
                bala6.setVisibility(View.VISIBLE);
                finperder.setVisibility(View.INVISIBLE);
                finganar.setVisibility(View.INVISIBLE);
                finganar2.setVisibility(View.INVISIBLE);
                finganar3.setVisibility(View.INVISIBLE);
                finganar4.setVisibility(View.INVISIBLE);
                finganar5.setVisibility(View.INVISIBLE);
                finganar6.setVisibility(View.INVISIBLE);
                continuar.setVisibility(View.INVISIBLE);
            }
        });
        menuprincipal.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Juego2.this, Menu.class);
                startActivity(intent);
            }
        });
        reiniciar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Collections.shuffle(tambor);
                bala1.setVisibility(View.VISIBLE);
                bala2.setVisibility(View.VISIBLE);
                bala3.setVisibility(View.VISIBLE);
                bala4.setVisibility(View.VISIBLE);
                bala5.setVisibility(View.VISIBLE);
                bala6.setVisibility(View.VISIBLE);
                finperder.setVisibility(View.INVISIBLE);
                finganar.setVisibility(View.INVISIBLE);
                finganar2.setVisibility(View.INVISIBLE);
                finganar3.setVisibility(View.INVISIBLE);
                finganar4.setVisibility(View.INVISIBLE);
                finganar5.setVisibility(View.INVISIBLE);
                finganar6.setVisibility(View.INVISIBLE);
                continuar.setVisibility(View.INVISIBLE);
            }
        });
    }

}
package com.example.ruletarusa;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.res.Resources;
import android.os.Bundle;

import java.io.IOException;
import java.util.Timer;
import java.util.TimerTask;

import pl.droidsonroids.gif.GifDrawable;

public class Portada<GifImageView> extends AppCompatActivity {
    private GifImageView gifImageView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        gifImageView= (GifImageView) findViewById(R.id.view);
        try {
            GifDrawable gifAnimado = new GifDrawable(getResources(),
                    R.drawable.portada);
            //gifImageView.setImageDrawable(gifAnimado);
        } catch (Resources.NotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        super.onStart();
        new Timer().schedule(new TimerTask(){
            @Override
            public void run(){
                Intent intent=new Intent(Portada.this, Menu.class);
                intent.addFlags(intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(intent);
                finish();
            }
        },8000);
    }
}
package com.example.permisos;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.os.Bundle;
import android.widget.LinearLayout;

public class Morse extends AppCompatActivity {
    EditText Entrada, Salida;
    Button botonCodificar, botonDecodificar, botonLimpiar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Entrada =(EditText) findViewById(R.id.textoentrada);
        Salida= (EditText) findViewById(R.id.textosalida);
        botonCodificar = (Button) findViewById(R.id.btnencode);
        botonDecodificar = (Button) findViewById(R.id.btndecode);
        botonLimpiar = (Button) findViewById(R.id.btnclear);
        final String[] Alfabeto = new String[37];
        final String[] AlfabetoMorse = new String[37];
        Alfabeto[0] = "A";
        Alfabeto[1] = "B";
        Alfabeto[2] = "C";
        Alfabeto[3] = "D";
        Alfabeto[4] = "E";
        Alfabeto[5] = "F";
        Alfabeto[6] = "G";
        Alfabeto[7] = "H";
        Alfabeto[8] = "I";
        Alfabeto[9] = "J";
        Alfabeto[10] = "K";
        Alfabeto[11] = "L";
        Alfabeto[12] = "M";
        Alfabeto[13] = "N";
        Alfabeto[14] = "O";
        Alfabeto[15] = "P";
        Alfabeto[16] = "Q";
        Alfabeto[17] = "R";
        Alfabeto[18] = "S";
        Alfabeto[19] = "T";
        Alfabeto[20] = "U";
        Alfabeto[21] = "V";
        Alfabeto[22] = "W";
        Alfabeto[23] = "X";
        Alfabeto[24] = "Y";
        Alfabeto[25] = "Z";
        Alfabeto[26] = "0";
        Alfabeto[27] = "1";
        Alfabeto[28] = "2";
        Alfabeto[29] = "3";
        Alfabeto[30] = "4";
        Alfabeto[31] = "5";
        Alfabeto[32] = "6";
        Alfabeto[33] = "7";
        Alfabeto[34] = "8";
        Alfabeto[35] = "9";
        Alfabeto[36] = " ";
        AlfabetoMorse[0] = ".-";
        AlfabetoMorse[1] = "-...";
        AlfabetoMorse[2] = "-.-.";
        AlfabetoMorse[3] = "-..";
        AlfabetoMorse[4] = ".";
        AlfabetoMorse[5] = "..-.";
        AlfabetoMorse[6] = "--.";
        AlfabetoMorse[7] = "....";
        AlfabetoMorse[8] = "..";
        AlfabetoMorse[9] = ".---";
        AlfabetoMorse[10] = "-.-";
        AlfabetoMorse[11] = ".-..";
        AlfabetoMorse[12] = "--";
        AlfabetoMorse[13] = "-.";
        AlfabetoMorse[14] = "---";
        AlfabetoMorse[15] = ".--.";
        AlfabetoMorse[16] = "--.-";
        AlfabetoMorse[17] = ".-.";
        AlfabetoMorse[18] = "...";
        AlfabetoMorse[19] = "-";
        AlfabetoMorse[20] = "..-";
        AlfabetoMorse[21] = "...-";
        AlfabetoMorse[22] = ".--";
        AlfabetoMorse[23] = "-..-";
        AlfabetoMorse[24] = "-.--";
        AlfabetoMorse[25] = "--..";
        AlfabetoMorse[26] = "-----";
        AlfabetoMorse[27] = ".----";
        AlfabetoMorse[28] = "..---";
        AlfabetoMorse[29] = "...--";
        AlfabetoMorse[30] = "....-";
        AlfabetoMorse[31] = ".....";
        AlfabetoMorse[32] = "-....";
        AlfabetoMorse[33] = "--...";
        AlfabetoMorse[34] = "---..";
        AlfabetoMorse[35] = "----.";
        AlfabetoMorse[36] = "/";

        botonCodificar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String entrada = Entrada.getText().toString();
                String salida = "";
                int l = entrada.length();
                int i, j;
                for (i = 0; i < l; i++) {
                    String ch = entrada.substring(i, i + 1);
                    Log.i("Caracteres", ch);
                    for (j = 0; j < 37; j++) {
                        if (ch.equalsIgnoreCase(Alfabeto[j])) {
                            salida = salida.concat(AlfabetoMorse[j]).concat(" ");
                            DividirSonido(salida);
                        }
                    }
                }
                Salida.setText(salida);
            }
        });

        botonLimpiar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Entrada.setText("");
                Salida.setText("");
            }
        });

        botonDecodificar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String input1 = Entrada.getText().toString();
                String input = input1.concat(" ");
                int l = input.length();
                int i, j, p = 0;
                int pos = 0;
                String letra = "";
                String output = "";
                for (i = 0; i < l; i++) {
                    int flag = 0;
                    String ch = input.substring(i, i + 1);
                    if (ch.equalsIgnoreCase(" ")) {
                        p = i;
                        letra = input.substring(pos, p);
                        pos = p + 1;
                        flag = 1;
                    }
                    String letter1 = letra.trim();
                    if (flag == 1) {
                        for (j = 0; j <= 36; j++) {
                            if (letter1.equalsIgnoreCase(AlfabetoMorse[j])) {
                                output = output.concat(Alfabeto[j]);
                                break;
                            }
                        }
                    }
                }
                Salida.setText(output);
            }
        });
    }

    private void DividirSonido(String cadena) {
        Pitido pitido0 = new Pitido(0, 10);
        Pitido pitido1 = new Pitido(0, 100);

        char caracter = 0;
        int i = 0;
        while (caracter != ' ') {
            caracter=cadena.charAt(i);
            if (caracter== '-') {
                Log.d("Caracter", "-");
                pitido1.sonar();
            } else {
                Log.d("Caracter", ".");
                pitido0.sonar();

            }
            i++;
        }
    }
}
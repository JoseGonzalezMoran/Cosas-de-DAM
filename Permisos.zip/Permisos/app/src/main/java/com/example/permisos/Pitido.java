package com.example.permisos;
import android.media.AudioManager;
import android.media.ToneGenerator;

public class Pitido {
    private int modo, duracion;
    ToneGenerator toneG = new ToneGenerator(AudioManager.STREAM_ALARM, 100);
    ToneGenerator toneGen1 = new ToneGenerator(AudioManager.STREAM_MUSIC, 100);

    public Pitido(int modo, int duracion)
    {
        this.modo=modo;
        this.duracion=duracion;

    }
    public void sonar(){
        switch (modo){
            case 0:
                toneG.startTone(ToneGenerator.TONE_DTMF_S, duracion);
                break;
            case 1:
                //               toneG.startTone(ToneGenerator.TONE_DTMF_S, duracion);
                toneGen1.startTone(ToneGenerator.TONE_CDMA_PIP,duracion);
                break;
        }
    }
}
package com.example.permisos;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Application;
import android.media.MediaPlayer;
import android.os.Bundle;

import java.util.Timer;
import java.util.TimerTask;

public class Contraportada extends AppCompatActivity {
    MediaPlayer reproductor=new MediaPlayer();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_contraportada);
        new Timer().schedule(new TimerTask(){
            @Override
            public void run(){
                //reproductor=MediaPlayer.create(this,R.raw.)
                finish();
            }
        },2000);
    }
}
package com.example.permisos;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class Foto extends AppCompatActivity {

    private ImageButton btncamera;
    private ImageView foto;
    private EditText nombrefoto;
    private ImageButton aceptar;
    private ImageButton cancelar;
    private String mCurrentPhotoPath;
    private Button vuelta;

    private void checkCameraPermission(){
        int permissionCheck= ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA);
        if(permissionCheck!= PackageManager.PERMISSION_GRANTED){
            Log.i("Aviso"," no se tiene permiso para acceder a la camara.");
            ActivityCompat.requestPermissions(this,new
            String[]{
                    Manifest.permission.CAMERA
            },225);
        }else{
            Log.i("Mensaje","Se tiene permiso para usar la camara.");
        }
    }
    private void guardarFoto() {
        Intent mediaScanIntent = new Intent(Intent.ACTION_MEDIA_SCANNER_SCAN_FILE);
        File f = new File("storage/emulated/0/Pictures"+nombrefoto);
        Uri contentUri = Uri.fromFile(f);
        mediaScanIntent.setData(contentUri);
        this.sendBroadcast(mediaScanIntent);
    }
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode,resultCode,data);
        if(resultCode== Activity.RESULT_OK){
            Bundle ext=data.getExtras();
            Bitmap bmp =(Bitmap) ext.get("data");
            foto.setImageBitmap(bmp);
        }
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_foto);
        checkCameraPermission();
        btncamera= (ImageButton) findViewById(R.id.botoncamara);
        foto=(ImageView) findViewById(R.id.fotocamara);
        nombrefoto=(EditText)findViewById(R.id.nombrefoto);
        aceptar=(ImageButton)findViewById(R.id.aceptar);
        cancelar=(ImageButton)findViewById(R.id.cancelar);
        vuelta=(Button)findViewById(R.id.vuelta);
        btncamera.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int id;
                id=v.getId();
                Intent i=new Intent(android.provider.MediaStore.ACTION_IMAGE_CAPTURE);
                startActivityForResult(i,0);
                btncamera.setVisibility(View.INVISIBLE);
                vuelta.setVisibility(View.INVISIBLE);
                nombrefoto.setVisibility(View.VISIBLE);
                aceptar.setVisibility(View.VISIBLE);
                cancelar.setVisibility(View.VISIBLE);
            }
        });
        vuelta.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(Foto.this, Menu.class);
                intent.addFlags(intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(intent);
                finish();
            }
        });
        aceptar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                guardarFoto();
                Toast.makeText(getApplicationContext(), "Imagen guardada con exito", Toast.LENGTH_SHORT).show();
                Intent intent=new Intent(Foto.this, Foto.class);
                intent.addFlags(intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(intent);
                finish();
            }
        });
        cancelar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(getApplicationContext(), "Imagen descartada", Toast.LENGTH_SHORT).show();
                Intent intent=new Intent(Foto.this, Foto.class);
                intent.addFlags(intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(intent);
                finish();
            }
        });
    }
}
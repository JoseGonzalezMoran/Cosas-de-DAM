package com.example.permisos;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.media.AudioManager;
import android.media.ToneGenerator;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;

public class Llamar extends AppCompatActivity {
    private Button volver;
    private ImageButton llamar;
    private EditText telefono;

    public class pitido {
        private int modo, duracion;
        ToneGenerator toneG = new ToneGenerator(AudioManager.STREAM_ALARM, 100);
        ToneGenerator toneGen1 = new ToneGenerator(AudioManager.STREAM_MUSIC, 100);
        public pitido(int modo, int duracion){
            this.modo=modo;
            this.duracion=duracion;
        }
        public void sonar(){
            switch (modo){
                case 0:
                    toneG.startTone(ToneGenerator.TONE_DTMF_S, duracion);
                    break;
                case 1:
                    toneGen1.startTone(ToneGenerator.TONE_CDMA_PIP,duracion);
                    break;
            }
        }
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_llamar);
        volver=(Button)findViewById(R.id.botonvolver);
        telefono=(EditText)findViewById(R.id.telefono);
        llamar=(ImageButton)findViewById(R.id.llamada);
        llamar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String numero=telefono.getText().toString();
                if (!numero.isEmpty()) {
                    String marcado="tel:"+numero;
                    startActivity(new Intent(Intent.ACTION_DIAL, Uri.parse(marcado)));
                }else {
                    Toast.makeText(Llamar.this, "Introducir número de teléfono...", Toast.LENGTH_SHORT).show();
                }
            }
        });
        volver.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(Llamar.this, Menu.class);
                intent.addFlags(intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(intent);
                finish();
            }
        });
    }
}
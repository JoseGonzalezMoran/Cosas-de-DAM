package com.example.permisos;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;

public class Menu extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu);
        Button registro=(Button)findViewById(R.id.registro);
        Button inicio=(Button)findViewById(R.id.inicio);
        Button iniciosesion=(Button)findViewById(R.id.Iniciarsesion);
        Button registrarse=(Button)findViewById(R.id.Registrarse);
        Button salir=(Button)findViewById(R.id.salir);
        TextView titulo=(TextView)findViewById(R.id.titulo);
        TextView nombre=(TextView)findViewById(R.id.nombre);
        TextView dni=(TextView)findViewById(R.id.dni);
        TextView email=(TextView)findViewById(R.id.email);
        TextView direccion=(TextView)findViewById(R.id.direccion);
        TextView telefonopersonal=(TextView)findViewById(R.id.telefonopersonal);
        TextView telefonoempresa=(TextView)findViewById(R.id.telefonoempresa);
        TextView cargo=(TextView)findViewById(R.id.cargo);
        TextView menu=(TextView)findViewById(R.id.menu);
        TextView llamar=(TextView)findViewById(R.id.llamar);
        TextView mensaje=(TextView)findViewById(R.id.mensaje);
        TextView foto=(TextView)findViewById(R.id.foto);
        TextView configuracion=(TextView)findViewById(R.id.configuracion);
        EditText NOMBRE=(EditText)findViewById(R.id.NOMBRE);
        EditText DNI=(EditText)findViewById(R.id.DNI);
        EditText EMAIL=(EditText)findViewById(R.id.EMAIL);
        EditText DIRECCION=(EditText)findViewById(R.id.DIRECCION);
        EditText TELEFONOPERSONAL=(EditText)findViewById(R.id.TELEFONOPERSONAL);
        EditText TELEFONOEMPRESA=(EditText)findViewById(R.id.TELEFONOEMPRESA);
        EditText CARGO=(EditText)findViewById(R.id.CARGO);
        TextView contraseña=(TextView)findViewById(R.id.contraseña);
        EditText CONTRASEÑA=(EditText)findViewById(R.id.CONTRASEÑA);
        ImageButton LLAMAR=(ImageButton)findViewById(R.id.LLAMAR);
        ImageButton MENSAJE=(ImageButton)findViewById(R.id.MENSAJE);
        ImageButton FOTO=(ImageButton)findViewById(R.id.FOTO);
        ImageButton CONFIGURACION=(ImageButton)findViewById(R.id.CONFIGURACION);
        Button morse=(Button)findViewById(R.id.morse);
        registro.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                registro.setVisibility(View.INVISIBLE);
                inicio.setVisibility(View.INVISIBLE);
                salir.setVisibility(View.INVISIBLE);
                nombre.setVisibility(View.VISIBLE);
                dni.setVisibility(View.VISIBLE);
                email.setVisibility(View.VISIBLE);
                direccion.setVisibility(View.VISIBLE);
                telefonopersonal.setVisibility(View.VISIBLE);
                telefonoempresa.setVisibility(View.VISIBLE);
                cargo.setVisibility(View.VISIBLE);
                NOMBRE.setVisibility(View.VISIBLE);
                DNI.setVisibility(View.VISIBLE);
                EMAIL.setVisibility(View.VISIBLE);
                DIRECCION.setVisibility(View.VISIBLE);
                TELEFONOPERSONAL.setVisibility(View.VISIBLE);
                TELEFONOEMPRESA.setVisibility(View.VISIBLE);
                CARGO.setVisibility(View.VISIBLE);
                registrarse.setVisibility(View.VISIBLE);
                contraseña.setVisibility(View.VISIBLE);
                CONTRASEÑA.setVisibility(View.VISIBLE);
                SharedPreferences prefs=getSharedPreferences("Mispreferencias", Context.MODE_PRIVATE);
                SharedPreferences.Editor editor=prefs.edit();
            }
        });
        inicio.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                inicio.setVisibility(View.INVISIBLE);
                registro.setVisibility(View.INVISIBLE);
                salir.setVisibility(View.INVISIBLE);
                nombre.setVisibility(View.VISIBLE);
                dni.setVisibility(View.VISIBLE);
                email.setVisibility(View.VISIBLE);
                direccion.setVisibility(View.VISIBLE);
                telefonopersonal.setVisibility(View.VISIBLE);
                telefonoempresa.setVisibility(View.VISIBLE);
                cargo.setVisibility(View.VISIBLE);
                NOMBRE.setVisibility(View.VISIBLE);
                DNI.setVisibility(View.VISIBLE);
                EMAIL.setVisibility(View.VISIBLE);
                DIRECCION.setVisibility(View.VISIBLE);
                TELEFONOPERSONAL.setVisibility(View.VISIBLE);
                TELEFONOEMPRESA.setVisibility(View.VISIBLE);
                CARGO.setVisibility(View.VISIBLE);
                iniciosesion.setVisibility(View.VISIBLE);
                contraseña.setVisibility(View.VISIBLE);
                CONTRASEÑA.setVisibility(View.VISIBLE);
            }
        });
        registrarse.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                nombre.setVisibility(View.INVISIBLE);
                dni.setVisibility(View.INVISIBLE);
                email.setVisibility(View.INVISIBLE);
                direccion.setVisibility(View.INVISIBLE);
                telefonopersonal.setVisibility(View.INVISIBLE);
                telefonoempresa.setVisibility(View.INVISIBLE);
                cargo.setVisibility(View.INVISIBLE);
                NOMBRE.setVisibility(View.INVISIBLE);
                DNI.setVisibility(View.INVISIBLE);
                EMAIL.setVisibility(View.INVISIBLE);
                DIRECCION.setVisibility(View.INVISIBLE);
                TELEFONOPERSONAL.setVisibility(View.INVISIBLE);
                TELEFONOEMPRESA.setVisibility(View.INVISIBLE);
                CARGO.setVisibility(View.INVISIBLE);
                registrarse.setVisibility(View.INVISIBLE);
                menu.setVisibility(View.VISIBLE);
                llamar.setVisibility(View.VISIBLE);
                mensaje.setVisibility(View.VISIBLE);
                foto.setVisibility(View.VISIBLE);
                configuracion.setVisibility(View.VISIBLE);
                morse.setVisibility(View.VISIBLE);
                LLAMAR.setVisibility(View.VISIBLE);
                FOTO.setVisibility(View.VISIBLE);
                MENSAJE.setVisibility(View.VISIBLE);
                CONFIGURACION.setVisibility(View.VISIBLE);
                titulo.setVisibility(View.INVISIBLE);
                contraseña.setVisibility(View.INVISIBLE);
                CONTRASEÑA.setVisibility(View.INVISIBLE);
            }
        });
        iniciosesion.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                nombre.setVisibility(View.INVISIBLE);
                dni.setVisibility(View.INVISIBLE);
                email.setVisibility(View.INVISIBLE);
                direccion.setVisibility(View.INVISIBLE);
                telefonopersonal.setVisibility(View.INVISIBLE);
                telefonoempresa.setVisibility(View.INVISIBLE);
                cargo.setVisibility(View.INVISIBLE);
                NOMBRE.setVisibility(View.INVISIBLE);
                DNI.setVisibility(View.INVISIBLE);
                EMAIL.setVisibility(View.INVISIBLE);
                DIRECCION.setVisibility(View.INVISIBLE);
                TELEFONOPERSONAL.setVisibility(View.INVISIBLE);
                TELEFONOEMPRESA.setVisibility(View.INVISIBLE);
                CARGO.setVisibility(View.INVISIBLE);
                iniciosesion.setVisibility(View.INVISIBLE);
                menu.setVisibility(View.VISIBLE);
                llamar.setVisibility(View.VISIBLE);
                mensaje.setVisibility(View.VISIBLE);
                foto.setVisibility(View.VISIBLE);
                morse.setVisibility(View.VISIBLE);
                configuracion.setVisibility(View.VISIBLE);
                LLAMAR.setVisibility(View.VISIBLE);
                FOTO.setVisibility(View.VISIBLE);
                MENSAJE.setVisibility(View.VISIBLE);
                CONFIGURACION.setVisibility(View.VISIBLE);
                titulo.setVisibility(View.INVISIBLE);
                contraseña.setVisibility(View.INVISIBLE);
                CONTRASEÑA.setVisibility(View.INVISIBLE);
            }
        });
        LLAMAR.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(Menu.this, Llamar.class);
                intent.addFlags(intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(intent);
                finish();
            }
        });
        FOTO.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(Menu.this, Foto.class);
                intent.addFlags(intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(intent);
                finish();
            }
        });
        MENSAJE.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(Menu.this, Mensaje.class);
                intent.addFlags(intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(intent);
                finish();
            }
        });
        CONFIGURACION.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                menu.setVisibility(View.INVISIBLE);
                titulo.setVisibility(View.VISIBLE);
                llamar.setVisibility(View.INVISIBLE);
                mensaje.setVisibility(View.INVISIBLE);
                foto.setVisibility(View.INVISIBLE);
                configuracion.setVisibility(View.INVISIBLE);
                morse.setVisibility(View.INVISIBLE);
                LLAMAR.setVisibility(View.INVISIBLE);
                MENSAJE.setVisibility(View.INVISIBLE);
                FOTO.setVisibility(View.INVISIBLE);
                CONFIGURACION.setVisibility(View.INVISIBLE);
                nombre.setVisibility(View.VISIBLE);
                dni.setVisibility(View.VISIBLE);
                email.setVisibility(View.VISIBLE);
                direccion.setVisibility(View.VISIBLE);
                telefonopersonal.setVisibility(View.VISIBLE);
                telefonoempresa.setVisibility(View.VISIBLE);
                cargo.setVisibility(View.VISIBLE);
                NOMBRE.setVisibility(View.VISIBLE);
                DNI.setVisibility(View.VISIBLE);
                EMAIL.setVisibility(View.VISIBLE);
                DIRECCION.setVisibility(View.VISIBLE);
                TELEFONOPERSONAL.setVisibility(View.VISIBLE);
                TELEFONOEMPRESA.setVisibility(View.VISIBLE);
                CARGO.setVisibility(View.VISIBLE);
                registrarse.setVisibility(View.VISIBLE);
                contraseña.setVisibility(View.VISIBLE);
                CONTRASEÑA.setVisibility(View.VISIBLE);
            }
        });
        salir.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(Menu.this, Contraportada.class);
                intent.addFlags(intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(intent);
                finish();
            }
        });
        morse.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(Menu.this, Morse.class);
                intent.addFlags(intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(intent);
                finish();
            }
        });
    }
}